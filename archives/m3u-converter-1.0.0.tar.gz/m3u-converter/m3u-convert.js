// The script of the m3u converter's page (extension m3u-converter).

// .webui-file companion: show a count instead of names for multi-select
function m3uFiles(sel) {
	var files = sel.files;
	if (files.length > 1) {
		sel.closest('.webui-file').querySelector('.webui-file-name').textContent =
			files.length + ' ' + webuiL('m3u.files', 'files');
	} else {
		webuiFileName(sel);
	}
	// every file read, then put in in the order chosen; one that cannot be
	// read is named, the others still come in
	var inp = document.getElementById('m3uInput');
	var failed = [];
	Promise.all(Array.prototype.map.call(files, function(f) {
		return f.text().catch(function() { failed.push(f.name); return null; });
	})).then(function(texts) {
		var got = texts.filter(function(t) { return t !== null; });
		got.forEach(function(t) { inp.value += (inp.value ? '\n' : '') + t; });
		if (failed.length)
			webuiShowToast(webuiL('m3u.read_fail', 'Could not be read') + ': ' + failed.join(', '), true);
		else if (got.length)
			webuiShowToast(got.length + ' ' + webuiL('m3u.loaded', 'file(s) loaded'));
	});
}

// a value as an XML attribute takes it: what XML gives a meaning there is
// written as a reference, so a name with a quote or a bracket stays a name
function m3uAttr(v) {
	return String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
		.replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// port of the Y_Tools_m3uConvert logic: #EXTINF provides the name,
// the following line the URL; udp://@ becomes udp/, every value is escaped
function m3uConvert() {
	var lines = document.getElementById('m3uInput').value.split('\n');
	var title = document.getElementById('m3uTitle').value;
	var desc = document.getElementById('m3uDesc').value;
	var genre = document.getElementById('m3uGenre').value;
	var s = '<?xml version="1.0"?>\n<webtvs name="[' + m3uAttr(title) + '] ">\n';
	var name = '';
	var count = 0;
	for (var i = 0; i < lines.length; i++) {
		var v = lines[i].trim();
		if (v === '') continue;
		// a line is a tag or a comment when it starts with #; an address
		// may hold one further on (a fragment) and stays an address
		if (v.charAt(0) === '#') {
			if (v.toUpperCase().indexOf('#EXTINF') !== -1) {
				var ci = v.indexOf(',');
				if (ci !== -1) name = v.substr(ci + 1);
			}
			continue;
		}
		var url = (v.toUpperCase().indexOf('UDP:') !== -1) ? v.replace('udp://@', 'udp/') : v;
		name = name.replace(/#EXTINF:|[0-9],|-[1-9],|,/g, '').replace(/^\s+/g, '');
		if (name === '') name = webuiL('m3u.channel', 'Channel') + ' ' + i;
		s += '    <webtv title="' + m3uAttr(name) + '" url="' + m3uAttr(url) +
			'" epgid="" genre="' + m3uAttr(genre) + '" description="' + m3uAttr(desc) + '" />\n';
		name = '';
		count++;
	}
	s += '</webtvs>';
	// nothing to convert is said as such, and leaves no empty list behind
	if (!count) {
		document.getElementById('m3uOutput').value = '';
		webuiShowToast(webuiL('m3u.none', 'No stream found: the text holds no address'), true);
		return;
	}
	document.getElementById('m3uOutput').value = s;
	webuiShowToast(count + ' ' + webuiL('m3u.converted', 'streams converted'));
}

function m3uDownload() {
	var out = document.getElementById('m3uOutput').value;
	if (!out) { webuiShowToast(webuiL('m3u.convert_first', 'Convert first'), true); return; }
	var name = document.getElementById('m3uName').value || 'webtv_usr.xml';
	var a = document.createElement('a');
	a.href = URL.createObjectURL(new Blob([out], {type: 'text/xml'}));
	a.download = name;
	a.click();
	URL.revokeObjectURL(a.href);
}

/* Saved into the directory the box keeps its own web TV lists in, which is
   where the file routes may write and where the settings' own uploads go
   (GET /api/v1/channels/sources names it), under the name given. */
async function m3uSaveToBox(btn) {
	var out = document.getElementById('m3uOutput').value;
	if (!out) { webuiShowToast(webuiL('m3u.convert_first', 'Convert first'), true); return; }
	var name = (document.getElementById('m3uName').value || 'webtv_usr.xml').replace(/[^A-Za-z0-9._-]/g, '_');
	btn.disabled = true;
	try {
		var src = await webuiV1('GET', '/channels/sources');
		var dir = String((src && src.webtv_dir) || '').replace(/\/+$/, '');
		if (!dir)
			throw new Error(webuiL('m3u.no_dir', 'The box names no folder for its WebTV lists'));
		await m3uStore({
			out: out,
			path: dir + '/' + name,
			add: document.getElementById('m3uAddSource').checked
		}, false);
	} catch (e) {
		webuiToastError(webuiL('msg.error', 'Error'), e);
	} finally {
		btn.disabled = false;
	}
}

/* One save as it was asked for: a question about replacing a file answers
   for this file and these bytes, whatever the fields say by then. A file
   that is one of the WebTV sources has the box read its lists again, also
   when it only replaced itself; where asked, one that is not yet becomes
   one, with the same reading. */
async function m3uStore(job, overwrite) {
	try {
		await webuiV1('PUT', '/storage/file', {query: {path: job.path, overwrite: overwrite ? 'true' : null},
			raw: new Blob([job.out], {type: 'text/xml'})});
	} catch (e) {
		if (e.code !== 'name-taken' || overwrite) throw e;
		webuiShowConfirm(webuiL('m3u.replace_title', 'Replace the file?'),
			webuiLH('m3u.replace_text', 'There is a file of this name on the box already:') + ' ' + escapeHtml(job.path),
			webuiL('m3u.replace', 'Replace'),
			function() {
				return m3uStore(job, true).catch(function(e2) {
					webuiToastError(webuiL('msg.error', 'Error'), e2);
				});
			});
		return;
	}
	var said = webuiL('m3u.saved', 'Saved') + ': ' + job.path;
	// the list as it is now, not as it was before a question: one changed
	// in the settings meanwhile is not written back over. The file is on
	// the box whatever happens here, and a failure says so.
	try {
		var now = await webuiV1('GET', '/channels/sources');
		var sources = (now && now.webtv) || [];
		var listed = sources.indexOf(job.path) >= 0;
		if (listed || job.add) {
			await webuiV1('PUT', '/channels/sources/webtv', {body: listed ? sources : sources.concat([job.path]),
				query: {reload: true}});
			said += ' – ' + (listed ? webuiL('m3u.source_known', 'already one of the WebTV sources, the channel lists are read again') :
				webuiL('m3u.source_added', 'added to the WebTV sources, the channel lists are read again'));
		}
	} catch (e) {
		webuiToastError(said + ' – ' + webuiL('m3u.source_fail', 'but not taken into the WebTV sources'), e);
		return;
	}
	webuiShowToast(said);
}

webuiExtTexts('m3u-converter').then(function() {
	// prefill only while untouched (English defaults from the markup)
	var ti = document.getElementById('m3uTitle');
	if (ti.value === 'my streams') ti.value = webuiL('m3u.title_default', 'my streams');
	var ge = document.getElementById('m3uGenre');
	if (ge.value === 'Movie') ge.value = webuiL('m3u.genre_default', 'Movie');
});
